# wxAMPS3

SEE Brief Introduction.pdf

Please acknowledge Prof. Rockett, Dr. Yiming Liu of UIUC and Prof. Fonash of PSU in any of your articles, reports, course lectures, and presentations which employ wxAMPS in simulation results.

Reference:
[1] Y. Liu, M. Ahmadpour, J. Adam, J. Kjelstrup-Hansen, H.-G. Rubahn, and M. Madsen, “Modeling Multijunction Solar Cells by Nonlocal Tunneling and Subcell Analysis,” IEEE J. Photovoltaics, vol. 8, no. 5, pp. 1363–1369, Sep. 2018.

If wxAMPS3 has problem running in your Windows, try following:
1. Run in compatibility mode, e.g., Win7
2. Add wxAMPS 3.exe to the white list of your firewall
3. Go to "System Properties"->"Advanced"-> "Performance" Settings -> "Data Execution Prevention":
   Check "Turn on DEP for all programs and services except those I select" -> Add wxAMPS 3.exe
