# MLinQCbook22-delta
